# E-Rapor Madrasah Offline — Android Native Source

Starter project aplikasi Android native Kotlin + Jetpack Compose dengan SQLite lokal. Tidak meminta permission INTERNET dan tidak menggunakan Google Drive, Google Sheets, akun, atau server. `android:allowBackup="false"` mencegah Android Auto Backup sistem.

## Fitur dalam source ini
- Dashboard guru dengan ringkasan siswa, mata pelajaran, dan entri nilai.
- Data siswa: tambah, edit, hapus; nama, NIS/NISN, kelas, jenis kelamin, orang tua/wali.
- Mata pelajaran: tambah, edit, hapus; kategori Umum, Agama, dan Muatan Lokal; KKM tiap pelajaran.
- Nilai harian, UTS, UAS; bobot nilai dapat diatur di Pengaturan dan nilai akhir dihitung berdasarkan bobot yang tersimpan.
- Penilaian kepribadian/sikap umum, kedisiplinan, dan kebersihan dengan pilihan Sangat Baik, Baik, Cukup, Perlu Bimbingan.
- Rekap kehadiran: hadir, sakit, izin, alpa.
- Catatan wali kelas manual dan tombol pembuat catatan otomatis sederhana yang masih bisa diedit.
- Pengaturan nama madrasah, wali kelas, tahun ajaran, semester, bobot penilaian.
- Cetak melalui Android Print Framework (pilih Save as PDF).
- Ekspor cadangan lokal JSON melalui pemilih berkas Android.
- Database SQLite internal aplikasi; skema versi 2 menambahkan kategori pelajaran dan aspek kedisiplinan/kebersihan.

## Membuat APK
APK belum dibangun di lingkungan pembuatan ini karena Android SDK/Gradle tidak tersedia. Folder ini adalah source project yang dapat dibuka dan dibangun di Android Studio.

1. Instal Android Studio stabil dan Android SDK Platform 35.
2. Buka folder `ERaporMadrasah` di Android Studio.
3. Gunakan JDK 17 dan tunggu Gradle Sync; komputer perlu internet satu kali untuk mengambil dependency Gradle/AndroidX.
4. Sambungkan HP Android dengan USB debugging aktif, lalu tekan Run untuk uji awal.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug akan dibuat di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP, izinkan instalasi dari sumber tersebut bila diminta, lalu instal. Untuk distribusi luas, buat APK bertanda tangan sendiri lewat **Build > Generate Signed Bundle / APK**.

## Pengujian sebelum penggunaan resmi
- Tambah, edit, dan hapus siswa; tutup-buka aplikasi dan pastikan data masih ada.
- Tambah mata pelajaran umum, agama, dan muatan lokal; ubah KKM setiap mata pelajaran.
- Uji nilai 0, 75, 100 dan bobot yang berbeda; cek perhitungan serta status tuntas.
- Uji kehadiran, sikap umum, kedisiplinan, kebersihan, dan catatan otomatis/manual.
- Cetak beberapa rapor PDF dan periksa format, pemotongan halaman, karakter Indonesia, tanda tangan, serta seluruh aspek kepribadian.
- Uji mode pesawat untuk memastikan fitur inti tetap bekerja.
- Uji pada perangkat Android dan ukuran layar yang berbeda.
- Uji ekspor JSON. Ekspor adalah cadangan manual lokal, bukan sinkronisasi cloud.

## Batasan yang harus diketahui
- Ini starter project/prototipe, bukan APK produksi yang sudah diuji pada perangkat nyata. Jangan langsung digunakan sebagai rapor resmi tanpa build, pengujian, dan validasi format.
- Template cetak masih format dasar. Struktur rapor resmi madrasah Kurikulum Merdeka dapat berbeda menurut jenjang (MI/MTs/MA), kelas, dan kebijakan madrasah. Bagian deskripsi capaian pembelajaran, ekstrakurikuler, kokurikuler/P5RA sesuai ketentuan berlaku, data kepala madrasah, tanda tangan, serta format tiap jenjang masih perlu diselaraskan.
- Catatan otomatis merupakan saran berbasis aturan sederhana, wajib ditinjau guru sebelum digunakan.
- Bobot awal 40/30/30 hanya contoh, bukan ketentuan nasional. Sesuaikan dengan kebijakan madrasah.
- Data hanya di perangkat. Jika HP rusak atau aplikasi dihapus, data dapat hilang; gunakan ekspor JSON ke lokasi aman secara berkala. Tidak ada pencadangan otomatis ke Google/server.
- Validasi input, impor/pemulihan JSON, dan pengujian migrasi database perlu dilengkapi sebelum pemakaian produksi.
