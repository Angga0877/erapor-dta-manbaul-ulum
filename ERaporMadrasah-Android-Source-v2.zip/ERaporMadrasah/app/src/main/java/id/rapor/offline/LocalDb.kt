package id.rapor.offline

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class LocalDb(context: Context) : SQLiteOpenHelper(context, "erapor_madrasah.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT, nis TEXT NOT NULL DEFAULT '', name TEXT NOT NULL, class_name TEXT NOT NULL DEFAULT '', gender TEXT NOT NULL DEFAULT '', parent_name TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE subjects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'Umum', kkm REAL NOT NULL DEFAULT 75, weight_daily REAL NOT NULL DEFAULT 40, weight_uts REAL NOT NULL DEFAULT 30, weight_uas REAL NOT NULL DEFAULT 30)")
        db.execSQL("CREATE TABLE scores(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL, subject_id INTEGER NOT NULL, daily REAL NOT NULL DEFAULT 0, uts REAL NOT NULL DEFAULT 0, uas REAL NOT NULL DEFAULT 0, attendance_present INTEGER NOT NULL DEFAULT 0, attendance_sick INTEGER NOT NULL DEFAULT 0, attendance_permission INTEGER NOT NULL DEFAULT 0, attendance_absent INTEGER NOT NULL DEFAULT 0, attitude TEXT NOT NULL DEFAULT 'Baik', discipline TEXT NOT NULL DEFAULT 'Baik', cleanliness TEXT NOT NULL DEFAULT 'Baik', teacher_note TEXT NOT NULL DEFAULT '', UNIQUE(student_id,subject_id), FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE, FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        val defaults = listOf("school_name" to "Nama Madrasah", "teacher_name" to "Nama Wali Kelas", "class_name" to "", "semester" to "Ganjil", "school_year" to "2026/2027", "daily_weight" to "40", "uts_weight" to "30", "uas_weight" to "30", "predikat_a" to "90", "predikat_b" to "80", "predikat_c" to "70")
        defaults.forEach { (k,v) -> val cv=ContentValues(); cv.put("key",k); cv.put("value",v); db.insert("settings",null,cv) }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE subjects ADD COLUMN category TEXT NOT NULL DEFAULT 'Umum'")
            db.execSQL("ALTER TABLE scores ADD COLUMN discipline TEXT NOT NULL DEFAULT 'Baik'")
            db.execSQL("ALTER TABLE scores ADD COLUMN cleanliness TEXT NOT NULL DEFAULT 'Baik'")
        }
    }

    fun addStudent(nis:String,name:String,clazz:String,gender:String,parent:String):Long {
        val v=ContentValues().apply { put("nis",nis); put("name",name); put("class_name",clazz); put("gender",gender); put("parent_name",parent) }
        return writableDatabase.insert("students",null,v)
    }
    fun updateStudent(id:Long,nis:String,name:String,clazz:String,gender:String,parent:String):Int {
        val v=ContentValues().apply { put("nis",nis); put("name",name); put("class_name",clazz); put("gender",gender); put("parent_name",parent) }
        return writableDatabase.update("students",v,"id=?", arrayOf(id.toString()))
    }
    fun deleteStudent(id:Long) { writableDatabase.delete("scores","student_id=?", arrayOf(id.toString())); writableDatabase.delete("students","id=?", arrayOf(id.toString())) }
    fun addSubject(name:String,category:String,kkm:Double):Long { val v=ContentValues().apply { put("name",name); put("category",category); put("kkm",kkm) }; return writableDatabase.insert("subjects",null,v) }
    fun updateSubject(id:Long,name:String,category:String,kkm:Double) { val v=ContentValues().apply { put("name",name); put("category",category); put("kkm",kkm) }; writableDatabase.update("subjects",v,"id=?", arrayOf(id.toString())) }
    fun deleteSubject(id:Long) { writableDatabase.delete("scores","subject_id=?", arrayOf(id.toString())); writableDatabase.delete("subjects","id=?", arrayOf(id.toString())) }
    fun saveScore(studentId:Long,subjectId:Long,daily:Double,uts:Double,uas:Double,present:Int,sick:Int,permission:Int,absent:Int,attitude:String,discipline:String,cleanliness:String,note:String) {
        val v=ContentValues().apply { put("student_id",studentId); put("subject_id",subjectId); put("daily",daily); put("uts",uts); put("uas",uas); put("attendance_present",present); put("attendance_sick",sick); put("attendance_permission",permission); put("attendance_absent",absent); put("attitude",attitude); put("discipline",discipline); put("cleanliness",cleanliness); put("teacher_note",note) }
        writableDatabase.insertWithOnConflict("scores",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun rows(sql:String):List<Map<String,String>> {
        val out=mutableListOf<Map<String,String>>(); readableDatabase.rawQuery(sql,null).use { c -> while(c.moveToNext()) { val row=mutableMapOf<String,String>(); for(i in 0 until c.columnCount) row[c.getColumnName(i)]=if(c.isNull(i)) "" else c.getString(i); out.add(row) } }; return out
    }
    fun getSetting(key:String, fallback:String=""):String = rows("SELECT value FROM settings WHERE key='${key.replace("'","''")}' LIMIT 1").firstOrNull()?.get("value") ?: fallback
    fun setSetting(key:String,value:String) { val v=ContentValues().apply { put("key",key); put("value",value) }; writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE) }
}
